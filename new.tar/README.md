# Embotics vCommander Jenkins Plugin  

This plugin allows Embotics vCommander users to create jobs in Jenkins  
and connect to vCommander through REST API connections.  
With this integration you can submit service requests, get status on  
existing requests and apply command workflows to Embotics-managed  
virtual machines.  
  
Embotics vCommander multi-cloud management platform is the fastest  
and easiest way to automate provisioning, enforce governance, and  
enable self-service IT across virtualized, private and public cloud  
infrastructures.  
  
https://www.embotics.com/  
2018 Embotics Corporation  
embotics.com  
Multi-Cloud Management Platform | Embotics vCommander  
Try Embotics vCommander Multi-Cloud Management Platform for faster provisioning, orchestration, self-service, governance, & cost optimization today.  
